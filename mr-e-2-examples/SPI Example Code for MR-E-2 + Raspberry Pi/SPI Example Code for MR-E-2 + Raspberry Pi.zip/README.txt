Contents of this package

- MR-E-2 + Resonant MR-10-30 demo unit.pptx : General presentation of the MR-E-2 with the resonant mirror MR-10-30.
The MR-10-30 and MR-15-30 are equivalent in terms of how to program them. They only differ in the mechanical response.

- SPI example with raspberry pi\ : Python modules to demonstrate SPI control with raspberry pi